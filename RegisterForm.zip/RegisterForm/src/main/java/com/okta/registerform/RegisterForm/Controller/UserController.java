package com.okta.registerform.RegisterForm.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.okta.registerform.RegisterForm.Entity.User;
import com.okta.registerform.RegisterForm.Service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;
	
	
	

	@GetMapping("/")
	public String register(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		System.out.println("gettig details from registration from");
		return "register";

	}

	@PostMapping("/registerUser")
	public String registerUser(@ModelAttribute("user") User user) {
		// String result = "error";
		System.out.println(user);
		// if(user.getPassword().equals(user.getCpassword())) {
		// try {
		System.out.println("posting the user details");
		service.registerUser(user);
		
		// result="home";
		// }

		// catch(Exception e){
		// System.out.println("error in catch block");
		// result ="error";

		// }
		// }
		
		
		return "home";
		

	}
	

}
