package com.okta.registerform.RegisterForm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegisterFormApplication.class, args);
		System.out.println("======== Application Started =======");
	}

}
