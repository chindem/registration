package com.okta.registerform.RegisterForm.Service;

import com.okta.registerform.RegisterForm.Entity.User;

public interface UserService  {

	 public void registerUser(User user);
}
