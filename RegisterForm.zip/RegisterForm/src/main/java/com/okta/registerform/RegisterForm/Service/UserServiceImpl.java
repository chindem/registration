package com.okta.registerform.RegisterForm.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.okta.registerform.RegisterForm.Entity.User;
import com.okta.registerform.RegisterForm.Repository.UserRepository;
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userrepo;
	
	@Override
	public void registerUser(User user) {
		// TODO Auto-generated method stub
		userrepo.save(user);
	}

}
